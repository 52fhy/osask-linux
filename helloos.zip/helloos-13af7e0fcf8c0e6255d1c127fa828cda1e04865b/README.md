# HELLO-OS
30日OS本の写経

### Reuirements

```
$ apt install qemu nasm
```

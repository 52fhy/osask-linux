# Day 19

### 1, 2. `type` コマンド

`cat` みたいな子

### 3. FATに対応

FAT: File Allocate Table

ファイルをどこに配置したのか的なやつ．
説明をみてもなにもわからない...あとWindowsじゃない...

### 4. ファイルの整理

はい．

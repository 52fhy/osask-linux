void HariMain(void)
{
    for(;;) {}
}
